:HL["/_next/static/chunks/91d763066838206a.css","style"]
:HL["/_next/static/chunks/fbc46a9d3d97b46f.css","style"]
0:{"buildId":"custom-build-id","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"set-up-new-center","paramType":null,"paramKey":"set-up-new-center","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
