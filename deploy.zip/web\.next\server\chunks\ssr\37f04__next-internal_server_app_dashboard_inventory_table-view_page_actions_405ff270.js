module.exports=[94651,(a,b,c)=>{}];

//# sourceMappingURL=37f04__next-internal_server_app_dashboard_inventory_table-view_page_actions_405ff270.js.map