1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/33ff04144bd9e688.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/33ff04144bd9e688.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"custom-build-id","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"SpaceJam - Coworking Space Management"}],["$","meta","1",{"name":"description","content":"Manage your coworking space efficiently"}]]}]}]}],null]}],"loading":null,"isPartial":false}
