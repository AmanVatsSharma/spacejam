module.exports=[41885,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_set-up-new-center_page_actions_f94c743c.js.map