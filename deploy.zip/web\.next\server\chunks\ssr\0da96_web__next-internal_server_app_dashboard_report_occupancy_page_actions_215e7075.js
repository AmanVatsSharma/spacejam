module.exports=[41867,(a,b,c)=>{}];

//# sourceMappingURL=0da96_web__next-internal_server_app_dashboard_report_occupancy_page_actions_215e7075.js.map