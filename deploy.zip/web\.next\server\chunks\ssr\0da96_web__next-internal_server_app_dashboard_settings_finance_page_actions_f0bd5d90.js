module.exports=[11727,(a,b,c)=>{}];

//# sourceMappingURL=0da96_web__next-internal_server_app_dashboard_settings_finance_page_actions_f0bd5d90.js.map