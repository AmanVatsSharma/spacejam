module.exports=[92506,(a,b,c)=>{}];

//# sourceMappingURL=37f04__next-internal_server_app_dashboard_inventory_floor-map_page_actions_cc10c84f.js.map