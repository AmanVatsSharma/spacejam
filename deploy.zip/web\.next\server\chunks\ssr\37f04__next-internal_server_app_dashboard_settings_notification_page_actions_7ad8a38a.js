module.exports=[67521,(a,b,c)=>{}];

//# sourceMappingURL=37f04__next-internal_server_app_dashboard_settings_notification_page_actions_7ad8a38a.js.map