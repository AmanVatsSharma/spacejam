var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/changelog/route.js")
R.c("server/chunks/[root-of-the-server]__cb27f5eb._.js")
R.c("server/chunks/[root-of-the-server]__e3ecfd17._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_changelog_route_actions_88c8bc4e.js")
R.m(95912)
module.exports=R.m(95912).exports
