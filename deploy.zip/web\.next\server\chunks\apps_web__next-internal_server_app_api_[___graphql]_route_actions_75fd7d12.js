module.exports=[63868,(e,o,d)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_api_%5B___graphql%5D_route_actions_75fd7d12.js.map