globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/05071ebaf3b40953.js",
    "static/chunks/c23c24f5be22d7ff.js",
    "static/chunks/ccc951ec8cf590b4.js",
    "static/chunks/15d74c2b524d3d42.js",
    "static/chunks/2e40bb08defb3e28.js",
    "static/chunks/turbopack-3c026e4e2227047b.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];