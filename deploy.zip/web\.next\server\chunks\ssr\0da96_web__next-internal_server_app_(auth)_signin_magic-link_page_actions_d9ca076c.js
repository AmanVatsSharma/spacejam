module.exports=[12023,(a,b,c)=>{}];

//# sourceMappingURL=0da96_web__next-internal_server_app_%28auth%29_signin_magic-link_page_actions_d9ca076c.js.map