module.exports=[46589,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}a.s(["default",()=>c])}];

//# sourceMappingURL=apps_web_src_app_dashboard_crm_layout_tsx_b3123929._.js.map