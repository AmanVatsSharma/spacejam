module.exports=[12203,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_changelog_page_actions_f9b6159f.js.map