module.exports=[83421,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_dashboard_inventory_page_actions_bcef92e6.js.map