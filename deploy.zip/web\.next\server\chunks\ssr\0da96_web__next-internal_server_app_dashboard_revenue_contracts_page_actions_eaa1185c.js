module.exports=[66435,(a,b,c)=>{}];

//# sourceMappingURL=0da96_web__next-internal_server_app_dashboard_revenue_contracts_page_actions_eaa1185c.js.map