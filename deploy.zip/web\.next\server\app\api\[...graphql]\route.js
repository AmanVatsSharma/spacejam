var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/[...graphql]/route.js")
R.c("server/chunks/[root-of-the-server]__fd186d4b._.js")
R.c("server/chunks/[root-of-the-server]__e3ecfd17._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_[___graphql]_route_actions_75fd7d12.js")
R.m(60183)
module.exports=R.m(60183).exports
