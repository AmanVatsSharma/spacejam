1:"$Sreact.fragment"
2:I[20103,["/_next/static/chunks/e6e373d73e6e15ca.js","/_next/static/chunks/97e7c56409e4b18f.js","/_next/static/chunks/f6ddf753def0dfc3.js","/_next/static/chunks/97d7633e71fdcc56.js","/_next/static/chunks/000f930abfd8cee5.js"],"default"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/33ff04144bd9e688.js"],"OutletBoundary"]
4:"$Sreact.suspense"
:HL["/_next/static/chunks/fbc46a9d3d97b46f.css","style"]
0:{"buildId":"custom-build-id","rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/fbc46a9d3d97b46f.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/000f930abfd8cee5.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
