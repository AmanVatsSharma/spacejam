module.exports=[29572,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_dashboard_revenue_page_actions_7af13079.js.map