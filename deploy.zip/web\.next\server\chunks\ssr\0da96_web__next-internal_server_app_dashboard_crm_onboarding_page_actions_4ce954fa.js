module.exports=[36561,(a,b,c)=>{}];

//# sourceMappingURL=0da96_web__next-internal_server_app_dashboard_crm_onboarding_page_actions_4ce954fa.js.map