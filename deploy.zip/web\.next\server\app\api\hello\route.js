var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/hello/route.js")
R.c("server/chunks/[root-of-the-server]__c4bf67f5._.js")
R.c("server/chunks/[root-of-the-server]__e3ecfd17._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_hello_route_actions_f3e356db.js")
R.m(65296)
module.exports=R.m(65296).exports
