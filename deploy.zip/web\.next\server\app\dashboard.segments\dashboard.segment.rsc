1:"$Sreact.fragment"
2:I[92825,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/33ff04144bd9e688.js"],"ClientSegmentRoot"]
3:I[26907,["/_next/static/chunks/e6e373d73e6e15ca.js","/_next/static/chunks/97e7c56409e4b18f.js","/_next/static/chunks/f6ddf753def0dfc3.js","/_next/static/chunks/97d7633e71fdcc56.js","/_next/static/chunks/91f67203d2793e9b.js","/_next/static/chunks/f3503a15367b127f.js"],"default"]
4:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/33ff04144bd9e688.js"],"default"]
5:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/33ff04144bd9e688.js"],"default"]
:HL["/_next/static/chunks/c91314868064c411.css","style"]
0:{"buildId":"custom-build-id","rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/c91314868064c411.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/91f67203d2793e9b.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/f3503a15367b127f.js","async":true}]],["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]},"serverProvidedParams":{"params":{},"promises":["$@6"]}}]]}],"loading":null,"isPartial":false}
6:"$0:rsc:props:children:1:props:serverProvidedParams:params"
