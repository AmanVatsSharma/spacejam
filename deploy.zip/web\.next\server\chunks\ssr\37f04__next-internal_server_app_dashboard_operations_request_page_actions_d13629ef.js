module.exports=[80878,(a,b,c)=>{}];

//# sourceMappingURL=37f04__next-internal_server_app_dashboard_operations_request_page_actions_d13629ef.js.map