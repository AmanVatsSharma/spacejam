module.exports=[46032,(e,o,d)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_api_changelog_route_actions_88c8bc4e.js.map