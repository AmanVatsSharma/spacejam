module.exports=[56707,42204,a=>{"use strict";var b=a.i(72131),c=a.i(47236),d=a.i(18236),e=a.i(10830),f=a.i(67858);let g=f.gql`
  query GetMeetingRooms($filters: RoomFiltersInput) {
    meetingRooms(filters: $filters) {
      id name type capacity status locationName floorId centerId
      minBookingDuration maxBookingDuration amenities hourlyRate active
      createdAt updatedAt
    }
  }
`;f.gql`
  query GetMeetingRoom($id: ID!) {
    meetingRoom(id: $id) {
      id name type capacity status locationName floorId centerId
      minBookingDuration maxBookingDuration amenities hourlyRate active
      center { id name }
      bookings { id title eventDate startTime endTime status }
    }
  }
`,f.gql`
  query GetAvailableRooms($centerId: String, $capacity: Int) {
    availableRooms(centerId: $centerId, capacity: $capacity) {
      id name type capacity status locationName amenities hourlyRate
    }
  }
`,f.gql`
  query GetRoomAvailability($centerId: String!, $floorId: String!, $eventDate: String!, $startTime: String!, $endTime: String!) {
    roomAvailability(centerId: $centerId, floorId: $floorId, eventDate: $eventDate, startTime: $startTime, endTime: $endTime) {
      id name type capacity status amenities hourlyRate
    }
  }
`;let h=f.gql`
  query GetEvents($filters: EventFiltersInput) {
    events(filters: $filters) {
      id centerId meetingRoomId requestedById title description company
      eventDate startTime endTime durationMinutes attendeesCount
      type status specialRequests addons cost notes
      createdAt updatedAt
      meetingRoom { id name }
      requestedBy { id name email }
    }
  }
`,i=f.gql`
  query GetEvent($id: ID!) {
    event(id: $id) {
      id centerId meetingRoomId requestedById title description company
      eventDate startTime endTime durationMinutes attendeesCount
      type status specialRequests addons cost notes
      meetingRoom { id name type capacity }
      requestedBy { id name email }
    }
  }
`;f.gql`
  query GetEventStatistics($centerId: String) {
    eventStatistics(centerId: $centerId) {
      totalEvents pendingEvents confirmedEvents completedEvents cancelledEvents
    }
  }
`;let j=f.gql`
  query GetRequests($filters: RequestFiltersInput) {
    requests(filters: $filters) {
      id centerId requestedById assignedToId type title description
      urgency status dueDate completedDate resolution cost attachedFile
      createdAt updatedAt
      requestedBy { id name }
      assignedTo { id name }
    }
  }
`;f.gql`
  query GetRequest($id: ID!) {
    request(id: $id) {
      id centerId requestedById assignedToId type title description
      urgency status dueDate completedDate resolution cost attachedFile
      createdAt updatedAt
      requestedBy { id name }
      assignedTo { id name }
    }
  }
`,f.gql`
  query GetRequestStatistics($centerId: String) {
    requestStats(centerId: $centerId) {
      totalRequests pendingRequests inProgressRequests completedRequests cancelledRequests highUrgencyRequests
    }
  }
`,f.gql`
  mutation CreateMeetingRoom($input: CreateMeetingRoomInput!) {
    createMeetingRoom(input: $input) {
      id name type capacity status locationName floorId amenities hourlyRate active
    }
  }
`,f.gql`
  mutation UpdateMeetingRoom($id: ID!, $input: UpdateMeetingRoomInput!) {
    updateMeetingRoom(id: $id, input: $input) {
      id name type capacity status locationName floorId amenities hourlyRate active
    }
  }
`,f.gql`
  mutation UpdateRoomStatus($id: ID!, $status: String!) {
    updateRoomStatus(id: $id, status: $status) {
      id name status
    }
  }
`,f.gql`
  mutation DeleteMeetingRoom($id: ID!) {
    deleteMeetingRoom(id: $id)
  }
`,f.gql`
  mutation BookRoom($roomId: String!, $centerId: String!, $eventDate: String!, $startTime: String!, $endTime: String!, $title: String!, $requestedBy: String) {
    bookRoom(roomId: $roomId, centerId: $centerId, eventDate: $eventDate, startTime: $startTime, endTime: $endTime, title: $title, requestedBy: $requestedBy) {
      id name status
    }
  }
`,f.gql`
  mutation CreateEvent($input: CreateEventInput!) {
    createEvent(input: $input) {
      success event { id title eventDate startTime endTime status cost }
      error
    }
  }
`,f.gql`
  mutation UpdateEvent($id: ID!, $input: UpdateEventInput!) {
    updateEvent(id: $id, input: $input) {
      success event { id title eventDate startTime endTime status cost }
      error
    }
  }
`;let k=f.gql`
  mutation UpdateEventStatus($id: ID!, $status: EventStatus!) {
    updateEventStatus(id: $id, status: $status) {
      success event { id title eventDate startTime endTime status cost }
      error
    }
  }
`,l=f.gql`
  mutation CancelEvent($id: ID!) {
    cancelEvent(id: $id)
  }
`;f.gql`
  mutation DeleteEvent($id: ID!) {
    deleteEvent(id: $id)
  }
`,f.gql`
  mutation CreateRequest($input: CreateRequestInput!) {
    createRequest(input: $input) {
      id title type urgency status dueDate cost
    }
  }
`;let m=f.gql`
  mutation UpdateRequest($id: ID!, $input: UpdateRequestInput!) {
    updateRequest(id: $id, input: $input) {
      id title type urgency status dueDate resolution cost
    }
  }
`,n=f.gql`
  mutation AssignRequest($id: ID!, $assignedToId: String!) {
    assignRequest(id: $id, assignedToId: $assignedToId) {
      id title urgency status assignedTo { id name }
    }
  }
`,o=f.gql`
  mutation CompleteRequest($id: ID!, $resolution: String) {
    completeRequest(id: $id, resolution: $resolution) {
      id title status completedDate resolution
    }
  }
`,p=f.gql`
  mutation RejectRequest($id: ID!, $resolution: String!) {
    rejectRequest(id: $id, resolution: $resolution) {
      id title status resolution
    }
  }
`;function q(a){let{data:b,loading:d,error:e,refetch:f}=(0,c.useQuery)(g,{variables:{filters:a},fetchPolicy:"cache-and-network",errorPolicy:"all"});return{rooms:b?.meetingRooms??[],loading:d,error:e,refetch:f}}function r(a){let{data:b,loading:d,error:e,refetch:f}=(0,c.useQuery)(h,{variables:{filters:a},fetchPolicy:"cache-and-network",errorPolicy:"all"});return{events:b?.events??[],data:b,loading:d,error:e,refetch:f}}function s(a){let{data:b,loading:d,error:e}=(0,c.useQuery)(i,{variables:{id:a},skip:!a,fetchPolicy:"cache-and-network",errorPolicy:"all"});return{event:b?.event??null,loading:d,error:e}}function t(){let a=(0,e.useApolloClient)(),[c,f]=(0,b.useState)(!1),[g]=(0,d.useMutation)(k,{errorPolicy:"all"});return{updateStatus:async function(b,c){f(!0);try{let d=await g({variables:{id:b,status:c}});return await a.refetchQueries({include:["GetEvents"]}),d.data?.updateEventStatus??{success:!1,error:"Unknown error",event:null}}finally{f(!1)}},saving:c}}function u(){let a=(0,e.useApolloClient)(),[c,f]=(0,b.useState)(!1),[g]=(0,d.useMutation)(l,{errorPolicy:"all"});return{cancel:async function(b){f(!0);try{let c=await g({variables:{id:b}});return await a.refetchQueries({include:["GetEvents"]}),!c.errors?.length}catch{return!1}finally{f(!1)}},cancelling:c}}function v(a){let{data:b,loading:d,error:e,refetch:f}=(0,c.useQuery)(j,{variables:{filters:a},fetchPolicy:"cache-and-network",errorPolicy:"all"});return{requests:b?.requests??[],loading:d,error:e,refetch:f}}function w(){let a=(0,e.useApolloClient)(),[c,f]=(0,b.useState)(!1),[g]=(0,d.useMutation)(m,{errorPolicy:"all"});return{update:async function(b,c){f(!0);try{let d=await g({variables:{id:b,input:c}});return await a.refetchQueries({include:["GetRequests"]}),d.data?.updateRequest??null}finally{f(!1)}},saving:c}}function x(){let a=(0,e.useApolloClient)(),[c,f]=(0,b.useState)(!1),[g]=(0,d.useMutation)(n,{errorPolicy:"all"});return{assign:async function(b,c){f(!0);try{let d=await g({variables:{id:b,assignedToId:c}});return await a.refetchQueries({include:["GetRequests"]}),d.data?.assignRequest??null}finally{f(!1)}},assigning:c}}function y(){let a=(0,e.useApolloClient)(),[c,f]=(0,b.useState)(!1),[g]=(0,d.useMutation)(o,{errorPolicy:"all"});return{complete:async function(b,c){f(!0);try{let d=await g({variables:{id:b,resolution:c}});return await a.refetchQueries({include:["GetRequests"]}),d.data?.completeRequest??null}finally{f(!1)}},saving:c}}function z(){let a=(0,e.useApolloClient)(),[c,f]=(0,b.useState)(!1),[g]=(0,d.useMutation)(p,{errorPolicy:"all"});return{reject:async function(b,c){f(!0);try{let d=await g({variables:{id:b,resolution:c}});return await a.refetchQueries({include:["GetRequests"]}),d.data?.rejectRequest??null}finally{f(!1)}},saving:c}}f.gql`
  mutation CancelRequest($id: ID!) {
    cancelRequest(id: $id)
  }
`,f.gql`
  mutation DeleteRequest($id: ID!) {
    deleteRequest(id: $id)
  }
`,a.s(["useAssignRequest",()=>x,"useCancelEvent",()=>u,"useCompleteRequest",()=>y,"useEvent",()=>s,"useEvents",()=>r,"useMeetingRooms",()=>q,"useRejectRequest",()=>z,"useRequests",()=>v,"useUpdateEventStatus",()=>t,"useUpdateRequest",()=>w],56707);var A=a.i(87924);let B=(0,A.jsxs)("span",{className:"inline-flex items-center gap-1.5 rounded-full bg-amber-50 px-2.5 py-1 text-[11px] font-semibold text-amber-700 ring-1 ring-amber-200 ml-2 align-middle",children:[(0,A.jsx)("svg",{className:"w-3 h-3",viewBox:"0 0 20 20",fill:"currentColor",children:(0,A.jsx)("path",{fillRule:"evenodd",d:"M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z",clipRule:"evenodd"})}),"Demo Data"]}),C=[{id:"boardroom-a",name:"Boardroom A",capacity:12,status:"occupied",booking:{label:"Current Booking",title:"Oracle ltd.",time:"10:00 AM - 11:30 AM"}},{id:"meeting-room-1",name:"Meeting Room 1",capacity:6,status:"available",booking:{label:"Next booking",title:"",time:"3:00 PM"}},{id:"conference-1",name:"Conference 1",capacity:20,status:"booked"},{id:"meeting-room-2",name:"Meeting Room 2",capacity:4,status:"available",booking:{label:"Next booking",title:"",time:"4:00 PM"}},{id:"boardroom-b",name:"Boardroom B",capacity:10,status:"occupied",booking:{label:"Current Booking",title:"Satyam Tech.",time:"9:30 AM - 12:00 PM"}},{id:"meeting-room-3",name:"Meeting Room 3",capacity:8,status:"available"},{id:"conference-2",name:"Conference 2",capacity:15,status:"maintenance"},{id:"meeting-room-4",name:"Meeting Room 4",capacity:6,status:"available",booking:{label:"Next booking",title:"",time:"5:00 PM"}},{id:"meeting-room-5",name:"Meeting Room 5",capacity:4,status:"occupied",booking:{label:"Current Booking",title:"Sahu Enterprise.",time:"11:00 AM - 12:30 PM"}},{id:"boardroom-c",name:"Boardroom C",capacity:12,status:"available",booking:{label:"Next booking",title:"",time:"2:30 PM"}},{id:"meeting-room-6",name:"Meeting Room 6",capacity:8,status:"booked"},{id:"conference-3",name:"Conference 3",capacity:18,status:"available"}];new Date().toISOString().split("T")[0];let D=[...[{id:"ev-t1",title:"Product Strategy Meeting",company:"TechCorp Inc.",date:"April 25, 2026",time:"09:00 AM",duration:"2 hours",room:"Room A",seats:8,addons:["Projector","Whiteboard"],notes:"Quarterly planning session",status:"confirmed"},{id:"ev-t2",title:"Client Onboarding Session",company:"StartupXYZ",date:"April 25, 2026",time:"11:30 AM",duration:"1 hour",room:"Room B",seats:6,addons:["TV Display"],notes:"Welcome walkthrough for the new cohort.",status:"confirmed"},{id:"ev-t3",title:"Design Workshop",company:"Creative Studios",date:"April 25, 2026",time:"02:00 PM",duration:"3 hours",room:"Conference Hall",seats:12,addons:["Whiteboard","Markers"],notes:"Hands-on UI exploration — bring laptops.",status:"pending"},{id:"ev-t4",title:"Investment Pitch",company:"VentureCap Partners",date:"April 25, 2026",time:"04:30 PM",duration:"1.5 hours",room:"Room C",seats:5,addons:["Projector"],notes:"Series A deck rehearsal.",status:"confirmed"}].map(a=>({...a,id:`fb-t-${a.id}`})),{id:"ev-u1",title:"Team Building Event",company:"InnovateCo",date:"April 28, 2026",time:"10:00 AM",duration:"4 hours",room:"Conference Hall",seats:25,addons:["Catering","Whiteboard"],notes:"Off-site team building — RSVP required.",status:"confirmed"},{id:"ev-u2",title:"Board Meeting",company:"FinTech Solutions",date:"May 02, 2026",time:"02:00 PM",duration:"2 hours",room:"Room A",seats:10,addons:["Projector","Conference Phone"],notes:"Quarterly board review.",status:"pending"},{id:"ev-u3",title:"Training Workshop",company:"EduTech Labs",date:"May 06, 2026",time:"09:30 AM",duration:"3 hours",room:"Room B",seats:15,addons:["Whiteboard","Markers","Projector"],notes:"Train-the-trainer session.",status:"confirmed"},{id:"ev-p1",title:"Annual General Meeting",company:"SpaceJam Co.",date:"April 10, 2026",time:"10:00 AM",duration:"2 hours",room:"Conference Hall",seats:40,addons:["Projector","Catering"],notes:"Annual general meeting for stakeholders.",status:"completed"}],E=[{id:"REQ-001",requestType:"Events",requestedBy:"Sarah Chen",details:"Conference room booking for team meeting",date:"24-04-2026",status:"Pending"},{id:"REQ-002",requestType:"Printer",requestedBy:"Mike Johnson",details:"Color printer access request",date:"21-04-2026",status:"Approved"},{id:"REQ-003",requestType:"Upgrade",requestedBy:"Emily Rodriguez",details:"Upgrade to premium desk space",date:"22-04-2026",status:"Pending"},{id:"REQ-004",requestType:"Services",requestedBy:"David Kim",details:"IT support for network setup",date:"20-04-2026",status:"Approved"},{id:"REQ-005",requestType:"Events",requestedBy:"Lisa Wang",details:"Workshop space for Friday afternoon",date:"23-04-2026",status:"Rejected"},{id:"REQ-006",requestType:"Printer",requestedBy:"James Taylor",details:"Bulk printing for marketing materials",date:"20-04-2026",status:"Pending"},{id:"REQ-007",requestType:"Upgrade",requestedBy:"Anna Martinez",details:"Additional storage locker request",date:"19-04-2026",status:"Approved"},{id:"REQ-008",requestType:"Services",requestedBy:"Tom Anderson",details:"Mail handling service setup",date:"18-04-2026",status:"Pending"}],F=[{icon:"payment",title:"Payment Failed",description:"Invoice #INV-1021 (₹4,200)"},{icon:"printer",title:"Printer Booked Today",description:"Patel Enterprises printer bo....."},{icon:"printer",title:"Printer Booked Today",description:"Patel Enterprises printer bo....."}];a.s(["DEMO_BADGE",0,B,"FALLBACK_ACTIVITIES",()=>F,"FALLBACK_EVENTS",()=>D,"FALLBACK_REQUESTS",()=>E,"FALLBACK_ROOMS",()=>C,"classifyByDate",0,(a,b)=>{let c=new Date(b).setHours(0,0,0,0),d=new Date(c).getTime();return{today:a.filter(a=>{let b=new Date(a.date).getTime();return b>=c&&b<d}),upcoming:a.filter(a=>new Date(a.date).getTime()>=d),past:a.filter(a=>new Date(a.date).getTime()<c)}},"mapStatus",0,a=>{let b=a.toLowerCase();return"available"===b?"available":"booked"===b||"occupied"===b?"booked":"maintenance"===b?"maintenance":"available"},"toEventRow",0,a=>({id:a.id,title:a.title,company:a.company??a.requestedBy?.name??"Unknown",date:a.eventDate,time:a.startTime,duration:`${a.durationMinutes} min`,room:a.meetingRoom?.name??"—",seats:a.attendeesCount??0,addons:a.addons??[],notes:a.notes??"",status:a.status?.toLowerCase()})],42204)}];

//# sourceMappingURL=apps_web_src_hooks_use-operations_ts_96564b3e._.js.map