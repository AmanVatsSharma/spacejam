:HL["/_next/static/chunks/91d763066838206a.css","style"]
:HL["/_next/static/chunks/c91314868064c411.css","style"]
:HL["/_next/static/chunks/f4c45f472c5cc095.css","style"]
0:{"buildId":"custom-build-id","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"dashboard","paramType":null,"paramKey":"dashboard","hasRuntimePrefetch":false,"slots":{"children":{"name":"report","paramType":null,"paramKey":"report","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
