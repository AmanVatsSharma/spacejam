1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/3e41285bdd0f6b09.js","/_next/static/chunks/33ff04144bd9e688.js","/_next/static/chunks/f6ddf753def0dfc3.js","/_next/static/chunks/97d7633e71fdcc56.js","/_next/static/chunks/97e7c56409e4b18f.js"],"default"]
3:I[37457,["/_next/static/chunks/3e41285bdd0f6b09.js","/_next/static/chunks/33ff04144bd9e688.js","/_next/static/chunks/f6ddf753def0dfc3.js","/_next/static/chunks/97d7633e71fdcc56.js","/_next/static/chunks/97e7c56409e4b18f.js"],"default"]
0:{"buildId":"custom-build-id","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
