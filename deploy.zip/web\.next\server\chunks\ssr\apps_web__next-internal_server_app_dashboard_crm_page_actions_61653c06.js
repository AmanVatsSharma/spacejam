module.exports=[50244,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_dashboard_crm_page_actions_61653c06.js.map