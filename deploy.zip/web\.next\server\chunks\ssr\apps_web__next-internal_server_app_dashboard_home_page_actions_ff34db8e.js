module.exports=[63327,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_dashboard_home_page_actions_ff34db8e.js.map