module.exports=[67294,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_dashboard_notifications_page_actions_9705a153.js.map