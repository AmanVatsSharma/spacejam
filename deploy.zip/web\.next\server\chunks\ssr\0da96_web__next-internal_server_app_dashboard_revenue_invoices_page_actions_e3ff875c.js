module.exports=[22915,(a,b,c)=>{}];

//# sourceMappingURL=0da96_web__next-internal_server_app_dashboard_revenue_invoices_page_actions_e3ff875c.js.map