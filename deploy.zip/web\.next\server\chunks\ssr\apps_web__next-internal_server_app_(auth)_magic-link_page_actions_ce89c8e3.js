module.exports=[38040,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_%28auth%29_magic-link_page_actions_ce89c8e3.js.map