module.exports=[43285,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/dynamic-access-async-storage.external.js",()=>require("next/dist/server/app-render/dynamic-access-async-storage.external.js"))},18622,(a,b,c)=>{b.exports=a.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},20635,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/action-async-storage.external.js",()=>require("next/dist/server/app-render/action-async-storage.external.js"))},24725,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},42602,(a,b,c)=>{"use strict";b.exports=a.r(18622)},87924,(a,b,c)=>{"use strict";b.exports=a.r(42602).vendored["react-ssr"].ReactJsxRuntime},72131,(a,b,c)=>{"use strict";b.exports=a.r(42602).vendored["react-ssr"].React},9270,(a,b,c)=>{"use strict";b.exports=a.r(42602).vendored.contexts.AppRouterContext},36313,(a,b,c)=>{"use strict";b.exports=a.r(42602).vendored.contexts.HooksClientContext},18341,(a,b,c)=>{"use strict";b.exports=a.r(42602).vendored.contexts.ServerInsertedHtml},35112,(a,b,c)=>{"use strict";b.exports=a.r(42602).vendored["react-ssr"].ReactDOM},38783,(a,b,c)=>{"use strict";b.exports=a.r(42602).vendored["react-ssr"].ReactServerDOMTurbopackClient},56846,a=>{"use strict";var b=a.i(67858);let c=b.gql`
  mutation Signin($input: SigninInput!) {
    signin(input: $input) {
      accessToken
      refreshToken
      accessTokenExpiresAt
      refreshTokenExpiresAt
      twoFactorRequired
      challengeToken
      user {
        id
        email
        name
        role
        active
        emailVerified
        twoFactorEnabled
      }
    }
  }
`,d=b.gql`
  mutation Signup($input: SignupInput!) {
    signup(input: $input) {
      accessToken
      refreshToken
      accessTokenExpiresAt
      refreshTokenExpiresAt
      twoFactorRequired
      challengeToken
      user {
        id
        email
        name
        role
        active
        emailVerified
        twoFactorEnabled
      }
    }
  }
`,e=b.gql`
  mutation VerifyTwoFactor($input: VerifyTwoFactorInput!) {
    verifyTwoFactor(input: $input) {
      accessToken
      refreshToken
      accessTokenExpiresAt
      refreshTokenExpiresAt
      user {
        id
        email
        name
        role
      }
    }
  }
`,f=b.gql`
  mutation Logout {
    logout
  }
`,g=b.gql`
  mutation RequestPasswordReset($input: ForgotPasswordInput!) {
    requestPasswordReset(input: $input)
  }
`,h=b.gql`
  mutation ResetPassword($input: ResetPasswordInput!) {
    resetPassword(input: $input)
  }
`,i=b.gql`
  query Me {
    me {
      id
      email
      name
      role
      active
      emailVerified
      twoFactorEnabled
      lastLoginAt
      createdAt
    }
  }
`,j=b.gql`
  mutation VerifyEmail($token: String!) {
    verifyEmail(token: $token) {
      ok
      message
    }
  }
`;b.gql`
  mutation ResendVerification {
    resendVerification {
      ok
      message
    }
  }
`;let k=b.gql`
  mutation ChangePassword($currentPassword: String!, $newPassword: String!) {
    changePassword(currentPassword: $currentPassword, newPassword: $newPassword) {
      ok
      message
    }
  }
`,l=b.gql`
  mutation RequestMagicLink($email: String!) {
    requestMagicLink(email: $email) {
      ok
      message
    }
  }
`,m=b.gql`
  mutation VerifyMagicLink($token: String!) {
    verifyMagicLink(token: $token) {
      accessToken
      refreshToken
      accessTokenExpiresAt
      refreshTokenExpiresAt
      twoFactorRequired
      user {
        id
        email
        name
        role
        active
        emailVerified
        twoFactorEnabled
        avatar
        lastLoginAt
        createdAt
      }
    }
  }
`,n=b.gql`
  query RecoveryCodesRemaining {
    recoveryCodesRemaining
  }
`,o=b.gql`
  mutation RegenerateRecoveryCodes {
    regenerateRecoveryCodes
  }
`,p=b.gql`
  query GetLeads($filters: LeadFiltersInput) {
    leads(filters: $filters) {
      id
      name
      email
      phone
      company
      source
      requirement
      budget
      location
      status
      lastContact
      assignedTo {
        id
        name
        email
      }
    }
  }
`,q=b.gql`
  mutation CreateLead($input: CreateLeadInput!) {
    createLead(input: $input) {
      id
      name
      email
      phone
      company
      source
      requirement
      budget
      location
      status
      lastContact
    }
  }
`,r=b.gql`
  mutation UpdateLead($id: ID!, $input: UpdateLeadInput!) {
    updateLead(id: $id, input: $input) {
      id
      name
      email
      phone
      company
      source
      requirement
      budget
      location
      status
      lastContact
    }
  }
`,s=b.gql`
  mutation ConvertLead($id: ID!) {
    convertLead(id: $id) {
      id
      status
    }
  }
`,t=b.gql`
  mutation DeleteLead($id: ID!) {
    deleteLead(id: $id)
  }
`,u=b.gql`
  query LeadCount($status: LeadStatus) {
    leadCount(status: $status)
  }
`,v=b.gql`
  query GetInvoices($filters: InvoiceFiltersInput) {
    invoices(filters: $filters) {
      id
      invoiceNumber
      customerId
      customerName
      customerEmail
      centerId
      planName
      amount
      tax
      totalAmount
      status
      issueDate
      dueDate
      paidDate
      paymentMethod
      notes
      createdAt
      updatedAt
    }
  }
`;b.gql`
  query GetInvoice($id: ID!) {
    invoice(id: $id) {
      id
      invoiceNumber
      customerId
      customerName
      customerEmail
      centerId
      planName
      amount
      tax
      totalAmount
      status
      issueDate
      dueDate
      paidDate
      paymentMethod
      notes
      createdAt
      updatedAt
    }
  }
`,b.gql`
  mutation CreateInvoice($input: CreateInvoiceInput!) {
    createInvoice(input: $input) {
      id
      invoiceNumber
      customerId
      customerName
      customerEmail
      centerId
      planName
      amount
      tax
      totalAmount
      status
      issueDate
      dueDate
      paidDate
      paymentMethod
      notes
      createdAt
      updatedAt
    }
  }
`,b.gql`
  mutation UpdateInvoice($id: ID!, $input: UpdateInvoiceInput!) {
    updateInvoice(id: $id, input: $input) {
      id
      invoiceNumber
      customerId
      customerName
      customerEmail
      centerId
      planName
      amount
      tax
      totalAmount
      status
      issueDate
      dueDate
      paidDate
      paymentMethod
      notes
      createdAt
      updatedAt
    }
  }
`;let w=b.gql`
  mutation DeleteInvoice($id: ID!) {
    deleteInvoice(id: $id)
  }
`,x=b.gql`
  mutation MarkInvoicePaid($id: ID!, $paymentMethod: String) {
    markInvoicePaid(id: $id, paymentMethod: $paymentMethod) {
      id
      invoiceNumber
      status
      paidDate
      paymentMethod
      updatedAt
    }
  }
`,y=b.gql`
  query InvoiceCount($status: InvoiceStatus) {
    invoiceCount(status: $status)
  }
`,z=b.gql`
  query GetDeposits($filters: DepositFiltersInput) {
    deposits(filters: $filters) {
      id
      customerId
      customerName
      centerId
      amount
      type
      status
      referenceNumber
      receivedDate
      releasedDate
      notes
      createdAt
      updatedAt
    }
  }
`;b.gql`
  query GetDeposit($id: ID!) {
    deposit(id: $id) {
      id
      customerId
      customerName
      centerId
      amount
      type
      status
      referenceNumber
      receivedDate
      releasedDate
      notes
      createdAt
      updatedAt
    }
  }
`,b.gql`
  mutation CreateDeposit($input: CreateDepositInput!) {
    createDeposit(input: $input) {
      id
      customerId
      customerName
      centerId
      amount
      type
      status
      referenceNumber
      receivedDate
      releasedDate
      notes
      createdAt
      updatedAt
    }
  }
`,b.gql`
  mutation UpdateDeposit($id: ID!, $input: UpdateDepositInput!) {
    updateDeposit(id: $id, input: $input) {
      id
      customerId
      customerName
      centerId
      amount
      type
      status
      referenceNumber
      receivedDate
      releasedDate
      notes
      createdAt
      updatedAt
    }
  }
`;let A=b.gql`
  mutation ReleaseDeposit($id: ID!) {
    releaseDeposit(id: $id) {
      id
      status
      releasedDate
      updatedAt
    }
  }
`,B=b.gql`
  mutation DeleteDeposit($id: ID!) {
    deleteDeposit(id: $id)
  }
`,C=b.gql`
  query GetContracts($filters: ContractFiltersInput) {
    contracts(filters: $filters) {
      id
      contractNumber
      customerId
      customerName
      centerId
      planName
      startDate
      endDate
      status
      amount
      paymentFrequency
      autoRenew
      terms
      createdAt
      updatedAt
    }
  }
`;b.gql`
  query GetContract($id: ID!) {
    contract(id: $id) {
      id
      contractNumber
      customerId
      customerName
      centerId
      planName
      startDate
      endDate
      status
      amount
      paymentFrequency
      autoRenew
      terms
      createdAt
      updatedAt
    }
  }
`,b.gql`
  mutation CreateContract($input: CreateContractInput!) {
    createContract(input: $input) {
      id
      contractNumber
      customerId
      customerName
      centerId
      planName
      startDate
      endDate
      status
      amount
      paymentFrequency
      autoRenew
      terms
      createdAt
      updatedAt
    }
  }
`,b.gql`
  mutation UpdateContract($id: ID!, $input: UpdateContractInput!) {
    updateContract(id: $id, input: $input) {
      id
      contractNumber
      customerId
      customerName
      centerId
      planName
      startDate
      endDate
      status
      amount
      paymentFrequency
      autoRenew
      terms
      createdAt
      updatedAt
    }
  }
`;let D=b.gql`
  mutation TerminateContract($id: ID!) {
    terminateContract(id: $id) {
      id
      status
      updatedAt
    }
  }
`,E=b.gql`
  query GetCustomers($filters: CustomerFiltersInput) {
    customers(filters: $filters) {
      id
      name
      email
      phone
      company
      status
      totalBookings
      totalSpent
      lastBooking
      createdAt
    }
  }
`;b.gql`
  query GetCustomer($id: ID!) {
    customer(id: $id) {
      id
      name
      email
      phone
      company
      status
      totalBookings
      totalSpent
      lastBooking
      createdAt
    }
  }
`,b.gql`
  mutation CreateCustomer($input: CreateCustomerInput!) {
    createCustomer(input: $input) {
      id
      name
      email
      phone
      company
      status
      totalBookings
      totalSpent
      lastBooking
      createdAt
    }
  }
`,b.gql`
  mutation UpdateCustomer($id: ID!, $input: UpdateCustomerInput!) {
    updateCustomer(id: $id, input: $input) {
      id
      name
      email
      phone
      company
      status
      totalBookings
      totalSpent
      lastBooking
      createdAt
    }
  }
`;let F=b.gql`
  mutation DeleteCustomer($id: ID!) {
    deleteCustomer(id: $id)
  }
`,G=b.gql`
  query GetDashboardMetrics($centerId: ID) {
    dashboardMetrics(centerId: $centerId) {
      totalRevenue
      occupancyRate
      activeBookings
      pendingPayments
      totalSeats
      availableSeats
    }
  }
`,H=b.gql`
  query GetRevenueReport($centerId: ID, $period: TimePeriod) {
    revenueReport(centerId: $centerId, period: $period) {
      total
      byMonth {
        month
        revenue
        target
      }
      growth
    }
  }
`;b.gql`
  query GetOccupancyReport($centerId: ID!, $period: TimePeriod) {
    occupancyReport(centerId: $centerId, period: $period) {
      centerId
      byDay {
        date
        totalBookings
        occupancyRate
        revenue
      }
      bySeatType {
        type
        count
        occupancyRate
      }
      averageRate
    }
  }
`,b.gql`
  query GetCenters {
    centers {
      id
      name
      status
      settings
      createdAt
      updatedAt
      location {
        id
        name
        city
        state
        country
        fullAddress
      }
      floors {
        id
        name
      }
    }
  }
`,b.gql`
  query GetCenter($id: ID!) {
    center(id: $id) {
      id
      name
      status
      settings
      createdAt
      updatedAt
      location {
        id
        name
        city
        state
        country
        fullAddress
      }
      floors {
        id
        name
      }
    }
  }
`;let I=b.gql`
  query GetMyCenters {
    myCenters {
      id
      name
      status
      settings
      createdAt
      updatedAt
      location {
        id
        name
        city
      }
      floors {
        id
        name
      }
    }
  }
`;b.gql`
  mutation CreateCenter($input: CreateCenterInput!) {
    createCenter(input: $input) {
      id
      name
      status
      settings
      createdAt
    }
  }
`;let J=b.gql`
  mutation UpdateCenter($id: ID!, $input: UpdateCenterInput!) {
    updateCenter(id: $id, input: $input) {
      id
      name
      status
      settings
      updatedAt
    }
  }
`;b.gql`
  query GetFloors($centerId: ID) {
    floors(centerId: $centerId) {
      id
      name
      layout
      createdAt
      updatedAt
    }
  }
`;let K=b.gql`
  query GetSeats($floorId: ID) {
    seats(floorId: $floorId) {
      id
      number
      type
      features
      status
      price
      location
      createdAt
      updatedAt
      floor {
        id
        name
      }
    }
  }
`;b.gql`
  mutation CreateSeat($input: CreateSeatInput!) {
    createSeat(input: $input) {
      id
      number
      type
      status
      price
    }
  }
`,b.gql`
  mutation UpdateSeat($id: ID!, $input: UpdateSeatInput!) {
    updateSeat(id: $id, input: $input) {
      id
      number
      type
      status
      price
    }
  }
`,a.s(["CHANGE_PASSWORD",0,k,"CONVERT_LEAD",0,s,"CREATE_LEAD",0,q,"DELETE_CUSTOMER",0,F,"DELETE_DEPOSIT",0,B,"DELETE_INVOICE",0,w,"DELETE_LEAD",0,t,"GET_CONTRACTS",0,C,"GET_CUSTOMERS",0,E,"GET_DASHBOARD_METRICS",0,G,"GET_DEPOSITS",0,z,"GET_INVOICES",0,v,"GET_LEADS",0,p,"GET_MY_CENTERS",0,I,"GET_REVENUE_REPORT",0,H,"GET_SEATS",0,K,"INVOICE_COUNT",0,y,"LEAD_COUNT",0,u,"LOGOUT_MUTATION",0,f,"MARK_INVOICE_PAID",0,x,"ME_QUERY",0,i,"RECOVERY_CODES_REMAINING",0,n,"REGENERATE_RECOVERY_CODES",0,o,"RELEASE_DEPOSIT",0,A,"REQUEST_MAGIC_LINK",0,l,"REQUEST_PASSWORD_RESET",0,g,"RESET_PASSWORD",0,h,"SIGNIN_MUTATION",0,c,"SIGNUP_MUTATION",0,d,"TERMINATE_CONTRACT",0,D,"UPDATE_CENTER",0,J,"UPDATE_LEAD",0,r,"VERIFY_EMAIL",0,j,"VERIFY_MAGIC_LINK",0,m,"VERIFY_TWO_FACTOR",0,e])},53879,(a,b,c)=>{"use strict";b.exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=void 0,b.exports.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=void 0,b.exports.__SERVER_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=void 0,Object.assign(b.exports,a.r(72131))},38979,a=>{"use strict";var b=a.i(53879),c=a.i(88010);a.i(25455);var d=a.i(95898),e=c.canUseSymbol?Symbol.for("__APOLLO_CONTEXT__"):"__APOLLO_CONTEXT__";function f(){(0,d.invariant)("createContext"in b,69);var a=b.createContext[e];return a||(Object.defineProperty(b.createContext,e,{value:a=b.createContext({}),enumerable:!1,writable:!1,configurable:!0}),a.displayName="ApolloContext"),a}a.s(["getApolloContext",()=>f])},51234,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"HandleISRError",{enumerable:!0,get:function(){return e}});let d=a.r(56704).workAsyncStorage;function e({error:a}){if(d){let b=d.getStore();if(b?.isStaticGeneration)throw a&&console.error(a),a}return null}("function"==typeof c.default||"object"==typeof c.default&&null!==c.default)&&void 0===c.default.__esModule&&(Object.defineProperty(c.default,"__esModule",{value:!0}),Object.assign(c.default,c),b.exports=c.default)},40622,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"default",{enumerable:!0,get:function(){return h}});let d=a.r(87924),e=a.r(51234),f={fontFamily:'system-ui,"Segoe UI",Roboto,Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji"',height:"100vh",textAlign:"center",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"},g={fontSize:"14px",fontWeight:400,lineHeight:"28px",margin:"0 8px"},h=function({error:a}){let b=a?.digest;return(0,d.jsxs)("html",{id:"__next_error__",children:[(0,d.jsx)("head",{}),(0,d.jsxs)("body",{children:[(0,d.jsx)(e.HandleISRError,{error:a}),(0,d.jsx)("div",{style:f,children:(0,d.jsxs)("div",{children:[(0,d.jsxs)("h2",{style:g,children:["Application error: a ",b?"server":"client","-side exception has occurred while loading ",window.location.hostname," (see the"," ",b?"server logs":"browser console"," for more information)."]}),b?(0,d.jsx)("p",{style:g,children:`Digest: ${b}`}):null]})})]})]})};("function"==typeof c.default||"object"==typeof c.default&&null!==c.default)&&void 0===c.default.__esModule&&(Object.defineProperty(c.default,"__esModule",{value:!0}),Object.assign(c.default,c),b.exports=c.default)},66594,a=>{"use strict";var b=a.i(87924),c=a.i(52100);a.i(25455);var d=a.i(95898),e=a.i(53879),f=a.i(38979),g=function(a){var b=a.client,g=a.children,h=(0,f.getApolloContext)(),i=e.useContext(h),j=e.useMemo(function(){return(0,c.__assign)((0,c.__assign)({},i),{client:b||i.client})},[i,b]);return(0,d.invariant)(j.client,71),e.createElement(h.Provider,{value:j},g)},h=a.i(80159),i=a.i(82915);function j({children:a}){let c=(0,h.getApolloClient)();return(0,b.jsx)(i.AuthProvider,{children:(0,b.jsx)(g,{client:c,children:a})})}a.s(["Providers",()=>j],66594)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__19f789fa._.js.map