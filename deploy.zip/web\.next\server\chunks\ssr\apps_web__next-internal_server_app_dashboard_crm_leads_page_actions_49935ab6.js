module.exports=[47680,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_dashboard_crm_leads_page_actions_49935ab6.js.map